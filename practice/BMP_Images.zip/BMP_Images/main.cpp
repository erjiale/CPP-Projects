// Compile with: 
// g++ -std=c++17 -Wall -Wextra -Wno-deprecated -Werror -pedantic -pedantic-errors "main.cpp" 
//      a.exe copy images images_out


#include "image.hpp"
// C++ Libraries
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<ctime>
#include<chrono>
// #include<filesystem>
// #include<experimental/filesystem>
// Para leer directorios
#include <dirent.h>
#include <sys/types.h>

using namespace std;
using namespace std::chrono;

bool isBmp(const char * fileName) {
    string file = fileName;
    string extension = "";
    bool ext_start = false;
    for(unsigned int i = 0; i < file.length(); i++) {
        if(ext_start) {
            extension += fileName[i];
            continue;
        }
        if(fileName[i]=='.') ext_start = true;
    }
    if(extension == "bmp") return true;
    return false;
}

// Comprobar si el directorio "dir" existe y si se puede abrir => TRUE, else FALSE
bool load(const char* dir) {
    DIR *dr;
    dr = opendir(dir); // abrir directorio
    if (dr) {
        closedir(dr); // cerrar directorio
        return true;
    }
    return false;
}

// Operation = COPIAR
// Copiar todos los archivos de "dir_in" a "dir_out"
void copy_file(const char* dir_in, const char* dir_out) {
    cout<<"Input path: " << dir_in << "\n";
    cout<<"Output path: " << dir_out << "\n";
    // Copiar cada archivo
    DIR *dr;
    struct dirent *entry;
    dr = opendir(dir_in); // abrir directorio de entrada
    BmpImage img;
    if (dr) {
        int count = 0;
        while ((entry = readdir(dr)) != NULL) {
            if(count >= 2) { // Ignore "." and ".."
                const char * fileName = entry->d_name;
                if(isBmp(fileName)) { // Asegurar el formato del archivo es '.bmp'
                    auto t0 = high_resolution_clock::now();
                    string construct_new_path_in = dir_in;
                    string construct_new_path_out = dir_out;
                    construct_new_path_in += "/";
                    construct_new_path_in += fileName;
                    construct_new_path_out += "/";
                    construct_new_path_out += fileName;
                    const char * fileName_out = construct_new_path_out.c_str();
                    const char * fileName_in = construct_new_path_in.c_str();
                    // Loading image from original directory
                    auto load_t0 = high_resolution_clock::now();
                    img.read(fileName_in);
                    auto load_t1 = high_resolution_clock::now();
                    auto load_time = duration_cast<microseconds>(load_t1 - load_t0);
                    // Copying and storing image to destination directory
                    auto copy_t0 = high_resolution_clock::now();
                    img.write(fileName_out);
                    auto copy_t1 = high_resolution_clock::now();
                    auto copy_time = duration_cast<microseconds>(copy_t1 - copy_t0);

                    // Calcular el tiempo total requerido para copiar cada archivo de un directorio a otro
                    auto t1 = high_resolution_clock::now();
                    auto duration = duration_cast<microseconds>(t1 - t0);
                    cout<<"File: \"" << fileName_in << "\"(time: " << duration.count() << ")" <<"\n";
                    cout<<" Load time: "<<load_time.count()<<"\n";
                    cout<<" Copy time: "<<copy_time.count()<<"\n";
                }
            }
            count++;
        }
        closedir(dr); // cerrar directorio
    }
    
    return;
}

int main(int argc, char *argv[]) {
    
    if(argc!=4) { //Si el número de los parámetros de entrada no son correctos
        cout<<"Wrong format :\n";
        cout<<" image-seq operation in_path out_path\n";
        cout<<"  operation: copy, gauss, sobel\n";
    }
    else if(string(argv[1])=="copy" || string(argv[1])=="sobel" || string(argv[1])=="gauss") { // asegurar q el segundo parametro es valido
        if(!load(argv[2])) { // Input_path not valid
            cout<<"Input path: "<<argv[2]<<"\n";
            cout<<"Output path: "<<argv[3]<<"\n";
            cout<<"Input directory ["<<argv[2]<<"]"<<" does not exist\n";
            cout<<" image-seq operation in_path out_path\n";
            cout<<"  operation: copy, gauss, sobel\n";
        }
        else if(!load(argv[3])) { // Output_path not valid
            cout<<"Input path: "<<argv[2]<<"\n";
            cout<<"Output path: "<<argv[3]<<"\n";
            cout<<"Output directory ["<<argv[3]<<"]"<<" does not exist\n";
            cout<<" image-seq operation in_path out_path\n";
            cout<<"  operation: copy, gauss, sobel\n";
        }
        else if(string(argv[1])=="copy") { // Copiar archivos del directorio de entrada al de salida
            copy_file(argv[2], argv[3]);


        }
        
    }
    else {
        cout<<"Unexpected operation:"<<argv[1]<<"\n";
        cout<<" image-seq operation in_path out_path\n";
        cout<<"  operation: copy, gauss, sobel\n";
    }
    
    return 0;
}