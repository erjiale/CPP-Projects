#ifndef IMAGE_HPP
#define IMAGE_HPP

#include "bmp.h"

#include <stdio.h>
#include <stdlib.h>

class BmpImage {
	private:
		LONG width;
		LONG height;

		RGBTRIPLE** data;
		
	public:
		// Getters
		LONG getWidth() { return width; }
		LONG getHeight() { return height; }

		// Methods
		bool read(const char* file) {
			// open file
			FILE* inptr = fopen(file, "r");
			if (inptr == NULL) {
				return false;
			}

			// read headers and set properties
			BITMAPFILEHEADER bf;
			fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);

			BITMAPINFOHEADER bi;
			fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);

			width = bi.biWidth;
			height = bi.biHeight;

			// calculate padding so line length becomes multiple of 4
			int padding = width * sizeof(RGBTRIPLE) % 4;

			// calculate row size
			int rowSize = width * sizeof(RGBTRIPLE) + padding;

			// read data row by row
			BYTE* row = new BYTE[rowSize];
			data = new RGBTRIPLE * [height];
			for (int i = 0; i < height; i++) {
				data[i] = new RGBTRIPLE[width];
				fread(row, sizeof(BYTE), rowSize, inptr);
				for (int j = 0; j < width; j++) {
					data[i][j] = {
						row[j * 3],
						row[j * 3 + 1],
						row[j * 3 + 2]
					};
				}
			}

			// close file
			fclose(inptr);

			return true;
		}

		bool write(const char* file) {
			// open file
			FILE* outptr = fopen(file, "w");
			if (outptr == NULL) {
				return false;
			}

			// get size of image
			int padding = width * sizeof(RGBTRIPLE) % 4;
			DWORD imgSize = height * (width * sizeof(RGBTRIPLE) + padding);

			// set/write headers
			BITMAPFILEHEADER bf;
			bf.bfType = 0x4D42; // "BM"
			bf.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + imgSize;
			bf.bfReserved1 = 0;
			bf.bfReserved2 = 0;
			bf.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
			fwrite(&bf, sizeof(BITMAPFILEHEADER), 1, outptr);

			BITMAPINFOHEADER bi;
			bi.biSize = sizeof(BITMAPINFOHEADER);
			bi.biWidth = width;
			bi.biHeight = height;
			bi.biPlanes = 1;
			bi.biBitCount = 24;
			bi.biCompression = 0;
			bi.biSizeImage = 0;
			bi.biXPelsPerMeter = 0;
			bi.biYPelsPerMeter = 0;
			bi.biClrUsed = 0;
			bi.biClrImportant = 0;
			fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, outptr);

			// write data
			for (int i = 0; i < height; i++) {
				// write row
				fwrite(data[i], sizeof(RGBTRIPLE), width, outptr);

				// write padding
				if (padding > 0) {
					for (int j = 0; j < padding; j++) {
						fputc(0x00, outptr);
					}
				}
			}

			// close file
			fclose(outptr);

			return true;
		}

		// void gaussian(BMP_Image& o, BMP_Image& result) {
		// 	BMP_Image& tmp (o);
		// 	Pixel color;
		
		// 	double linc_r,linc_g,linc_b;
		
		// 	//Remember these ?
		// 	int gauss_w = 7;                            // Level(+1)
		// 	int mask[gauss_w]={1,6,15,20,15,6,1}; // Mask
		// 	int gauss_sum=64;                           // Sum
		
		// 	byte R,G,B;
		// 	//For every pixel on the temporary bitmap ...
		// 	for(int i=gauss_w-1;i<tmp.getHeight()-1;i++) {
		// 		for(int j=1;j<tmp.getWidth()-1;j++) {
		// 			sumr=0;
		// 			sumg=0;
		// 			sumb=0;
		// 			for(int k=0;k<gauss_w;k++) {
		// 				color=o.getPixel(j,i-(gauss_w-1)+k);
		// 				R=color.getRed();
		// 				G=color.getGreen();
		// 				B=color.getBlue();
		// 				linc_r+=R*mask[k];
		// 				linc_g+=G*mask[k];
		// 				linc_b+=B*mask[k];
		// 			}
		// 			tmp.drawPixel(Pixel(linc_r/gauss_sum,linc_g/gauss_sum,linc_b/gauss_sum),j,i);
		// 		}
		// 	}
		// 	//For every pixel on the output bitmap ...
		// 	for(int i=1;i<result.getHeight()-1;i++) {
		// 		for(int j=gauss_w;j<result.getWidth()-1;j++){
		// 			sumr=0;
		// 			sumg=0;
		// 			sumb=0;
		// 			for(int k=0;k<gauss_w;k++){
		// 				color=tmp.getPixel(j-(gauss_w-1)+k,i);
		// 				R=color.getRed();
		// 				G=color.getGreen();
		// 				B=color.getBlue();
				
		// 				linc_r+=R*mask[k];
		// 				linc_g+=G*mask[k];
		// 				linc_b+=B*mask[k];
		// 			}
		// 			linc_r/=gauss_sum;
		// 			linc_g/=gauss_sum;
		// 			linc_b/=gauss_sum;
			
		// 			//Don't copy my unsafe casting!
		// 			// result.drawPixel(Pixel((byte)link_r,(byte)link_g,(byte)link_b),j,i);
		// 		}
		// 	}
		// }

};

#endif